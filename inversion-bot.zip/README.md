robot-service
=============

The project title is Infrastructure optimization for Well Placement Real Time Inversion. This project aims to optimize today Well Placement work flow. 